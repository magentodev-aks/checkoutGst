<?php
namespace Custom\GstForm\Controller\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Checkout\Model\Session;

class GstData extends Action
{
    protected $jsonFactory;
    protected $checkoutSession;

    public function __construct(
        Context $context,
        JsonFactory $jsonFactory,
        Session $checkoutSession
    ) {
        parent::__construct($context);
        $this->jsonFactory = $jsonFactory;
        $this->_checkoutSession = $checkoutSession;
    }

    public function execute()
    {
        $response = $this->jsonFactory->create();
        $postData = $this->getRequest()->getPostValue();

        dd($postData);

        $this->_checkoutSession->setVarValue('someValueHere');
        // dd($this->_checkoutSession->getVarValue());

        $result = ['success' => true, 'message' => 'Data saved successfully.']; // Adjust as needed
        return $response->setData($result);
    }
}
